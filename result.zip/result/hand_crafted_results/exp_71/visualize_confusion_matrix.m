clear; close all; clc; 
confmat = [ 19, 0, 0, 1, 0, 0, 0, 0, 0, 0;
0, 34, 0, 0, 0, 0, 0, 0, 0, 0;
0, 0, 22, 0, 0, 0, 0, 0, 0, 0;
0, 0, 0, 9, 0, 0, 0, 2, 0, 0;
0, 0, 0, 0, 27, 0, 0, 1, 0, 0;
0, 0, 2, 0, 0, 48, 0, 0, 1, 0;
0, 0, 0, 0, 0, 0, 23, 0, 0, 0;
0, 0, 0, 2, 1, 0, 0, 30, 0, 0;
0, 0, 0, 0, 0, 1, 0, 0, 27, 0;
1, 0, 0, 0, 0, 0, 0, 0, 0, 56;
];

% plotting
plotConfusionMatrix(confmat, { 'Bottle', 'Bowl', 'Flask', 'Fork', 'Knife', 'Mug', 'Plate', 'Spoon', 'Teapot', 'Vase', });




%%
function plotConfusionMatrix(varargin)
%PLOTCONFMAT plots the confusion matrix with colorscale, absolute numbers
%and precision normalized percentages
%
%   usage: 
%   PLOTCONFMAT(confmat) plots the confmat with integers 1 to n as class labels
%PLOTCONFMAT(confmat, labels) plots the confmat with the specified labels
%
%   Arguments
%   confmat:			a square confusion matrix
%labels (optional):  vector of class labels

% number of arguments
switch (nargin)
	case 0
		confmat = 1;
		labels = {'1'};
	case 1
		confmat = varargin{1};
		labels = 1:size(confmat, 1);
	otherwise
		confmat = varargin{1};
		labels = varargin{2};
end

confmat(isnan(confmat))=0; % in case there are NaN elements
numlabels = size(confmat, 1); % number of labels

% calculate the percentage accuracies
confpercent = 100*confmat./sum(confmat, 2);

% plotting the colors
imagesc(confpercent);
title(sprintf('Accuracy: %.2f%% (TEST_COR)', 100*trace(confmat)/sum(confmat(:))));
ylabel('Predicted Category','FontSize',15); xlabel('Target Category','FontSize',15);

% set the colormap
colormap(flipud(hot));
colorbar;

% Create strings from the matrix values and remove spaces
textStrings = num2str([confpercent(:), confmat(:)], '%.1f%%\n%d');
textStrings = strtrim(cellstr(textStrings));

% Create x and y coordinates for the strings and plot them
[x,y] = meshgrid(1:numlabels);
hStrings = text(x(:),y(:),textStrings(:), ...
'HorizontalAlignment','center');

% Get the middle value of the color range
midValue = mean(get(gca,'CLim'))

% Choose white or black for the text color of the strings so
% they can be easily seen over the background color
textColors = repmat(confpercent(:) > midValue,1,3);
set(hStrings,{'Color'},num2cell(textColors,2));

% Setting the axis labels
truesize([450 550]);
set(gca,'XTick',1:numlabels,...
		'XTickLabel',labels,...
		'YTick',1:numlabels,...
		'YTickLabel',labels,...
		'TickLength',[0 0]);
end
